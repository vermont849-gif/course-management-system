<?php include "config.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-primary d-flex justify-content-center align-items-center vh-100">

<div class="card p-4 shadow" style="width:350px;">
    <h3 class="text-center mb-3">Register</h3>

    <form method="POST">
        <input type="text" name="name" class="form-control mb-3" placeholder="Name" required>
        <input type="email" name="email" class="form-control mb-3" placeholder="Email" required>
        <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
        <button name="register" class="btn btn-dark w-100">Register</button>
    </form>

    <p class="text-center mt-3">
        Already have an account? <a href="login.php">Login</a>
    </p>

    <?php
    if (isset($_POST['register'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

        if ($conn->query("INSERT INTO users (name,email,password) VALUES ('$name','$email','$pass')")) {
            echo "<div class='alert alert-success mt-3'>Registered successfully</div>";
        } else {
            echo "<div class='alert alert-danger mt-3'>Error</div>";
        }
    }
    ?>
</div>

</body>
</html>