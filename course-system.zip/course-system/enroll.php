<?php
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
}

$user_id = $_SESSION['user_id'];
$course_id = $_GET['id'];

$conn->query("INSERT IGNORE INTO enrollments (user_id, course_id)
VALUES ($user_id, $course_id)");

header("Location: dashboard.php");
?>