<?php 
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
}

$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-3">
    <span class="navbar-brand">Course System</span>
    <a href="logout.php" class="btn btn-danger">Logout</a>
</nav>

<div class="container mt-4">

    <h3>Available Courses</h3>
    <div class="row">
    <?php
    $courses = $conn->query("SELECT * FROM courses");
    while ($row = $courses->fetch_assoc()) {
    ?>
        <div class="col-md-4">
            <div class="card mb-3 shadow">
                <div class="card-body">
                    <h5><?= $row['course_name'] ?></h5>
                    <p><?= $row['course_code'] ?></p>
                    <a href="enroll.php?id=<?= $row['id'] ?>" class="btn btn-success w-100">Enroll</a>
                </div>
            </div>
        </div>
    <?php } ?>
    </div>

    <h3 class="mt-5">My Courses</h3>
    <div class="row">
    <?php
    $query = "
    SELECT courses.* FROM courses
    JOIN enrollments ON courses.id = enrollments.course_id
    WHERE enrollments.user_id = $user_id
    ";
    $result = $conn->query($query);

    while ($row = $result->fetch_assoc()) {
    ?>
        <div class="col-md-4">
            <div class="card mb-3 border-danger shadow">
                <div class="card-body">
                    <h5><?= $row['course_name'] ?></h5>
                    <a href="drop.php?id=<?= $row['id'] ?>" class="btn btn-danger w-100">Drop</a>
                </div>
            </div>
        </div>
    <?php } ?>
    </div>

</div>

</body>
</html>